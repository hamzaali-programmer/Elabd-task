document.addEventListener('DOMContentLoaded', function() {
    // Get the login button and login container
    const loginButton = document.getElementById('loginButton');
    const loginContainer = document.querySelector('.login-container');
    
    // Create modal overlay
    const modalOverlay = document.createElement('div');
    modalOverlay.className = 'modal-overlay';
    document.body.appendChild(modalOverlay);
    
    // Add close button to login container
    const closeButton = document.createElement('button');
    closeButton.innerHTML = '&times;';
    closeButton.className = 'modal-close-btn';
    document.querySelector('.login-section').prepend(closeButton);
    
    // Function to open modal
    function openLoginModal() {
        loginContainer.classList.add('active');
        modalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent scrolling when modal is open
    }
    
    // Function to close modal
    function closeLoginModal() {
        loginContainer.classList.remove('active');
        modalOverlay.classList.remove('active');
        document.body.style.overflow = ''; // Restore scrolling
    }
    
    // Event listeners
    loginButton.addEventListener('click', openLoginModal);
    closeButton.addEventListener('click', closeLoginModal);
    modalOverlay.addEventListener('click', closeLoginModal);
});


document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const registerBtn = document.querySelector('.register-link'); // This would be in your navbar
    const loginLink = document.getElementById('loginLink');
    const registerModalOverlay = document.getElementById('registerModalOverlay');
    const registerContainer = document.querySelector('.register-container');
    const registerCloseBtn = document.getElementById('registerCloseBtn');
    const passwordToggles = document.querySelectorAll('.password-toggle');
    
    // Open register modal when register button is clicked
    if (registerBtn) {
        registerBtn.addEventListener('click', function(e) {
            e.preventDefault();
            registerModalOverlay.classList.add('active');
            registerContainer.classList.add('active');
            
            // Close login modal if open
            const loginContainer = document.querySelector('.login-container');
            const loginOverlay = document.querySelector('#loginModalOverlay');
            if (loginContainer && loginContainer.classList.contains('active')) {
                loginContainer.classList.remove('active');
                loginOverlay.classList.remove('active');
            }
        });
    }
    
    // Close register modal
    if (registerCloseBtn) {
        registerCloseBtn.addEventListener('click', function() {
            registerModalOverlay.classList.remove('active');
            registerContainer.classList.remove('active');
        });
    }
    
    // Close register modal when clicking outside
    registerModalOverlay.addEventListener('click', function(e) {
        if (e.target === registerModalOverlay) {
            registerModalOverlay.classList.remove('active');
            registerContainer.classList.remove('active');
        }
    });
    
    // Switch to login modal
    if (loginLink) {
        loginLink.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Close register modal
            registerModalOverlay.classList.remove('active');
            registerContainer.classList.remove('active');
            
            // Open login modal
            const loginContainer = document.querySelector('.login-container');
            const loginOverlay = document.querySelector('#loginModalOverlay');
            if (loginContainer && loginOverlay) {
                loginContainer.classList.add('active');
                loginOverlay.classList.add('active');
            }
        });
    }
    
    // Toggle password visibility
    passwordToggles.forEach(function(toggle) {
        toggle.addEventListener('click', function() {
            const input = this.parentNode.querySelector('input');
            const type = input.getAttribute('type');
            
            if (type === 'password') {
                input.setAttribute('type', 'text');
                this.innerHTML = `
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-slash" viewBox="0 0 16 16">
                        <path d="M13.359 11.238C15.06 9.72 16 8 16 8s-3-5.5-8-5.5a7.028 7.028 0 0 0-2.79.588l.77.771A5.944 5.944 0 0 1 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.134 13.134 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755-.165.165-.337.328-.517.486l.708.709z"/>
                        <path d="M11.297 9.176a3.5 3.5 0 0 0-4.474-4.474l.823.823a2.5 2.5 0 0 1 2.829 2.829l.822.822zm-2.943 1.299.822.822a3.5 3.5 0 0 1-4.474-4.474l.823.823a2.5 2.5 0 0 0 2.829 2.829z"/>
                        <path d="M3.35 5.47c-.18.16-.353.322-.518.487A13.134 13.134 0 0 0 1.172 8l.195.288c.335.48.83 1.12 1.465 1.755C4.121 11.332 5.881 12.5 8 12.5c.716 0 1.39-.133 2.02-.36l.77.772A7.029 7.029 0 0 1 8 13.5C3 13.5 0 8 0 8s.939-1.721 2.641-3.238l.708.709zm10.296 8.884-12-12 .708-.708 12 12-.708.708z"/>
                    </svg>
                `;
            } else {
                input.setAttribute('type', 'password');
                this.innerHTML = `
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye" viewBox="0 0 16 16">
                        <path d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8zM1.173 8a13.133 13.133 0 0 1 1.66-2.043C4.12 4.668 5.88 3.5 8 3.5c2.12 0 3.879 1.168 5.168 2.457A13.133 13.133 0 0 1 14.828 8c-.058.087-.122.183-.195.288-.335.48-.83 1.12-1.465 1.755C11.879 11.332 10.119 12.5 8 12.5c-2.12 0-3.879-1.168-5.168-2.457A13.134 13.134 0 0 1 1.172 8z"/>
                        <path d="M8 5.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM4.5 8a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0z"/>
                    </svg>
                `;
            }
        });
    });
});




document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const forgotPasswordLink = document.querySelector('.forgot-password'); // Link in login modal
    const backToLoginLink = document.getElementById('backToLoginLink');
    const registerLinkFromForgot = document.getElementById('registerLinkFromForgot');
    const forgotPasswordModalOverlay = document.getElementById('forgotPasswordModalOverlay');
    const forgotPasswordContainer = document.querySelector('.forgot-password-container');
    const forgotPasswordCloseBtn = document.getElementById('forgotPasswordCloseBtn');
    
    // Open forgot password modal when "Forgot your password?" is clicked
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Close login modal if open
            const loginContainer = document.querySelector('.login-container');
            const loginOverlay = document.querySelector('#loginModalOverlay');
            if (loginContainer && loginContainer.classList.contains('active')) {
                loginContainer.classList.remove('active');
                if (loginOverlay) loginOverlay.classList.remove('active');
            }
            
            // Open forgot password modal
            forgotPasswordModalOverlay.classList.add('active');
            forgotPasswordContainer.classList.add('active');
        });
    }
    
    // Close forgot password modal
    if (forgotPasswordCloseBtn) {
        forgotPasswordCloseBtn.addEventListener('click', function() {
            forgotPasswordModalOverlay.classList.remove('active');
            forgotPasswordContainer.classList.remove('active');
        });
    }
    
    // Close forgot password modal when clicking outside
    forgotPasswordModalOverlay.addEventListener('click', function(e) {
        if (e.target === forgotPasswordModalOverlay) {
            forgotPasswordModalOverlay.classList.remove('active');
            forgotPasswordContainer.classList.remove('active');
        }
    });
    
    // Back to login modal
    if (backToLoginLink) {
        backToLoginLink.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Close forgot password modal
            forgotPasswordModalOverlay.classList.remove('active');
            forgotPasswordContainer.classList.remove('active');
            
            // Open login modal
            const loginContainer = document.querySelector('.login-container');
            const loginOverlay = document.querySelector('#loginModalOverlay');
            if (loginContainer && loginOverlay) {
                loginContainer.classList.add('active');
                loginOverlay.classList.add('active');
            }
        });
    }
    
    // Switch to register modal
    if (registerLinkFromForgot) {
        registerLinkFromForgot.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Close forgot password modal
            forgotPasswordModalOverlay.classList.remove('active');
            forgotPasswordContainer.classList.remove('active');
            
            // Open register modal
            const registerContainer = document.querySelector('.register-container');
            const registerOverlay = document.querySelector('#registerModalOverlay');
            if (registerContainer && registerOverlay) {
                registerContainer.classList.add('active');
                registerOverlay.classList.add('active');
            }
        });
    }
});